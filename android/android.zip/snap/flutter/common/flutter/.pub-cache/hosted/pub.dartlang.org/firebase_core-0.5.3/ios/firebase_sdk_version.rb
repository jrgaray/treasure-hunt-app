def firebase_sdk_version!()
  '6.33.0'
end
