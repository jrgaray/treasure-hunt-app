package com.jrai.flutter_keyboard_visibility_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
