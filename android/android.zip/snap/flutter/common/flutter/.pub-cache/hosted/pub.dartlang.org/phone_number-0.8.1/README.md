# Phone Number for Flutter

PhoneNumber is a Flutter plugin that allows you to parse, validate and format international phone numbers.

The plugin uses the native libraries [libphonenumber](https://github.com/google/libphonenumber) for Android and [PhoneNumberKit](https://github.com/marmelroy/PhoneNumberKit) pod for iOS.

|Library|Version|
|--|--|
|libphonenumber|`8.12.9`|
|PhoneNumberKit|`3.3.1`|

## Usage

### Parsing
_TODO_

### Validating
_TODO_

### Formatting
_TODO_
